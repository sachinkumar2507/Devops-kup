#include<iostream>
#include<stdio.h>
int main(){
	using namespace std;
	cout<<"this is sachin kumar debian package\n";
}
